﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR23_Nikolaev
{
    public partial class EditTovarsForm : Form
    {
        private TovarsForm tovarsForm;
        public EditTovarsForm()
        {
            InitializeComponent();
            var tip = new ToolTip();

            tip.SetToolTip(nameTextBox, "Введите наименование товара");
            tip.SetToolTip(descriptionTextBox, "Введите пояснение к товару");
            tip.SetToolTip(markTextBox, "укажите оценку товара по 5-тибалльной шкале");
        }

        private void productsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.pK_shopDataSet);

        }

        private void EditTovarsForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pK_shopDataSet.Products". При необходимости она может быть перемещена или удалена.
            this.productsTableAdapter.Fill(this.pK_shopDataSet.Products);

        }

        private void butAddProd_Click(object sender, EventArgs e)
        {
            productsBindingSource.AddNew();
        }

        private void butDelProd_Click(object sender, EventArgs e)
        {
            productsBindingSource.RemoveCurrent();
        }

        private void butSaveProd_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.pK_shopDataSet);
        }

        private void butSearchProd_Click(object sender, EventArgs e)
        {
            string sql = String.Concat("SELECT * FROM Products WHERE IdProducts=", idProductsTextBox.Text);

            string connectiongString;
            connectiongString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";


            SqlConnection connection = new SqlConnection(connectiongString);
            connection.Open();

            SqlCommand command = new SqlCommand(sql, connection);
            SqlDataReader dataReader = command.ExecuteReader();

            nameTextBox.Text = "";
            priceTextBox.Text = "";
            countTextBox.Text = "";
            markTextBox.Text = "";
            descriptionTextBox.Text = "";
            while (dataReader.Read())
            {
                nameTextBox.Text += dataReader["Name"];
                priceTextBox.Text += dataReader["Price"];
                countTextBox.Text += dataReader["Count"];
                markTextBox.Text += dataReader["Mark"];
                descriptionTextBox.Text += dataReader["Description"];
            }

            dataReader.Close();
            connection.Close();
        }

        private void buttClear_Click(object sender, EventArgs e)
        {
            nameTextBox.Text = "";
            priceTextBox.Text = "";
            countTextBox.Text = "";
            markTextBox.Text = "";
            descriptionTextBox.Text = "";
        }

        private void butTablProd_Click(object sender, EventArgs e)
        {
            tovarsForm = new TovarsForm();
            tovarsForm.Visible = true;
        }

        private void priceTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && (e.KeyChar != 8) && (e.KeyChar != 44))
            {
                e.Handled = true;
            }
        }

        private void countTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && (e.KeyChar != 8) && (e.KeyChar != 44))
            {
                e.Handled = true;
            }
        }
    }
}
