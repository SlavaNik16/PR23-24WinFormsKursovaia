﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR23_Nikolaev
{
    public partial class TovarsForm : Form
    {
        private DataGridViewColumn col;
        public TovarsForm()
        {
            InitializeComponent();
            var tip = new ToolTip();
            tip.SetToolTip(comboName, "Выберите в таблице строку с наименованием и нажмите фильтровать");
            tip.SetToolTip(textBox1, "укажите код товара");
        }

        private void TovarsForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pK_shopDataSet.Products". При необходимости она может быть перемещена или удалена.
            this.productsTableAdapter.Fill(this.pK_shopDataSet.Products);

        }



        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            butSort.Enabled = true;
        }

        private void butSort_Click(object sender, EventArgs e)
        {
            col = new DataGridViewColumn();
            switch (listBox.SelectedIndex)
            {
                case 0:
                    col = nameDataGridViewTextBoxColumn;
                    break;
                case 1:
                    col = priceDataGridViewTextBoxColumn;
                    break;
                case 2:
                    col = countDataGridViewTextBoxColumn;
                    break;
                case 3:
                    col = markDataGridViewTextBoxColumn;
                    break;
                case 4:
                    col = descriptionDataGridViewTextBoxColumn;
                    break;
            }

            if (radioOrder.Checked)
                dataGridViewProduct.Sort(col, ListSortDirection.Ascending);
            else
                dataGridViewProduct.Sort(col, ListSortDirection.Descending);
        }

        private void butFiltr_Click(object sender, EventArgs e)
        {
            try
            {
                bindingSourceTableProd.Filter = "Name='" + comboName.Text + "'";
            }
            catch (Exception)
            {

            }
        }

        private void butViewAll_Click(object sender, EventArgs e)
        {
            bindingSourceTableProd.Filter = "";
        }

        private void butSearch_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < dataGridViewProduct.ColumnCount-1; i++)
            {
                for(int j = 0; j < dataGridViewProduct.RowCount-1; j++)
                {
                    dataGridViewProduct[i, j].Style.BackColor = Color.White;
                    dataGridViewProduct[i, j].Style.ForeColor = Color.Black;
                }
            }
            for (int i = 0; i < dataGridViewProduct.ColumnCount-1; i++)
            {
                for (int j = 0; j < dataGridViewProduct.RowCount-1; j++)
                {
                    if (dataGridViewProduct[i, j].Value.ToString().IndexOf(textBox1.Text) != -1)
                    {
                        dataGridViewProduct[i, j].Style.BackColor = Color.AliceBlue;
                        dataGridViewProduct[i, j].Style.ForeColor = Color.Blue;
                    }
                }
            }
        }

        private void butClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void comboName_MouseEnter(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "выберите наименование товара для фильтрации";

        }
    }
}
