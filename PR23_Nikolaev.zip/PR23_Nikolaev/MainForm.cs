﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR23_Nikolaev
{
    
    public partial class MainForm : Form
    {
        private BuyersForm buyers;
        private EditTovarsForm editTovarsForm;
        public MainForm()
        {
            InitializeComponent();
        }

        private void BuyersMenu_Click(object sender, EventArgs e)
        {
            buyers = new BuyersForm();
            buyers.Visible= true;
        }

        private void TovarsMenu_Click(object sender, EventArgs e)
        {
            editTovarsForm = new EditTovarsForm();
            editTovarsForm.Visible= true;
        }

        private void выходToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Николаев В.А. ИП-20-3","О программе");
        }

        private void просмотрСправкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, helpProvider1.HelpNamespace);
        }
    }
}
