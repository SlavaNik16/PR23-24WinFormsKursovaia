﻿namespace PR23_Nikolaev
{
    partial class EditTovarsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idProductsLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label priceLabel;
            System.Windows.Forms.Label countLabel;
            System.Windows.Forms.Label markLabel;
            System.Windows.Forms.Label descriptionLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditTovarsForm));
            this.pK_shopDataSet = new PR23_Nikolaev.PK_shopDataSet();
            this.productsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productsTableAdapter = new PR23_Nikolaev.PK_shopDataSetTableAdapters.ProductsTableAdapter();
            this.tableAdapterManager = new PR23_Nikolaev.PK_shopDataSetTableAdapters.TableAdapterManager();
            this.productsBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.productsBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.idProductsTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.countTextBox = new System.Windows.Forms.TextBox();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.butSearchProd = new System.Windows.Forms.Button();
            this.butAddProd = new System.Windows.Forms.Button();
            this.butDelProd = new System.Windows.Forms.Button();
            this.buttClear = new System.Windows.Forms.Button();
            this.butSaveProd = new System.Windows.Forms.Button();
            this.butTablProd = new System.Windows.Forms.Button();
            this.markTextBox = new System.Windows.Forms.MaskedTextBox();
            this.priceTextBox = new System.Windows.Forms.MaskedTextBox();
            idProductsLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            priceLabel = new System.Windows.Forms.Label();
            countLabel = new System.Windows.Forms.Label();
            markLabel = new System.Windows.Forms.Label();
            descriptionLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pK_shopDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingNavigator)).BeginInit();
            this.productsBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // idProductsLabel
            // 
            idProductsLabel.AutoSize = true;
            idProductsLabel.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            idProductsLabel.Location = new System.Drawing.Point(42, 53);
            idProductsLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            idProductsLabel.Name = "idProductsLabel";
            idProductsLabel.Size = new System.Drawing.Size(113, 23);
            idProductsLabel.TabIndex = 1;
            idProductsLabel.Text = "Код товара:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            nameLabel.Location = new System.Drawing.Point(42, 123);
            nameLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(145, 23);
            nameLabel.TabIndex = 3;
            nameLabel.Text = "Наименование:";
            // 
            // priceLabel
            // 
            priceLabel.AutoSize = true;
            priceLabel.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            priceLabel.Location = new System.Drawing.Point(42, 193);
            priceLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            priceLabel.Name = "priceLabel";
            priceLabel.Size = new System.Drawing.Size(60, 23);
            priceLabel.TabIndex = 5;
            priceLabel.Text = "Цена:";
            // 
            // countLabel
            // 
            countLabel.AutoSize = true;
            countLabel.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            countLabel.Location = new System.Drawing.Point(42, 258);
            countLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            countLabel.Name = "countLabel";
            countLabel.Size = new System.Drawing.Size(121, 23);
            countLabel.TabIndex = 7;
            countLabel.Text = "Количество:";
            // 
            // markLabel
            // 
            markLabel.AutoSize = true;
            markLabel.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            markLabel.Location = new System.Drawing.Point(41, 319);
            markLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            markLabel.Name = "markLabel";
            markLabel.Size = new System.Drawing.Size(81, 23);
            markLabel.TabIndex = 9;
            markLabel.Text = "Оценка:";
            // 
            // descriptionLabel
            // 
            descriptionLabel.AutoSize = true;
            descriptionLabel.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            descriptionLabel.Location = new System.Drawing.Point(41, 373);
            descriptionLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new System.Drawing.Size(102, 23);
            descriptionLabel.TabIndex = 11;
            descriptionLabel.Text = "Описание:";
            // 
            // pK_shopDataSet
            // 
            this.pK_shopDataSet.DataSetName = "PK_shopDataSet";
            this.pK_shopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productsBindingSource
            // 
            this.productsBindingSource.DataMember = "Products";
            this.productsBindingSource.DataSource = this.pK_shopDataSet;
            // 
            // productsTableAdapter
            // 
            this.productsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ProductsTableAdapter = this.productsTableAdapter;
            this.tableAdapterManager.UpdateOrder = PR23_Nikolaev.PK_shopDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UsersTableAdapter = null;
            // 
            // productsBindingNavigator
            // 
            this.productsBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.productsBindingNavigator.BindingSource = this.productsBindingSource;
            this.productsBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.productsBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.productsBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.productsBindingNavigatorSaveItem});
            this.productsBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.productsBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.productsBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.productsBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.productsBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.productsBindingNavigator.Name = "productsBindingNavigator";
            this.productsBindingNavigator.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.productsBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.productsBindingNavigator.Size = new System.Drawing.Size(523, 25);
            this.productsBindingNavigator.TabIndex = 0;
            this.productsBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(96, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // productsBindingNavigatorSaveItem
            // 
            this.productsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.productsBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("productsBindingNavigatorSaveItem.Image")));
            this.productsBindingNavigatorSaveItem.Name = "productsBindingNavigatorSaveItem";
            this.productsBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.productsBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.productsBindingNavigatorSaveItem.Click += new System.EventHandler(this.productsBindingNavigatorSaveItem_Click);
            // 
            // idProductsTextBox
            // 
            this.idProductsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "IdProducts", true));
            this.idProductsTextBox.Location = new System.Drawing.Point(199, 50);
            this.idProductsTextBox.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.idProductsTextBox.Name = "idProductsTextBox";
            this.idProductsTextBox.Size = new System.Drawing.Size(267, 32);
            this.idProductsTextBox.TabIndex = 2;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(199, 120);
            this.nameTextBox.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(267, 32);
            this.nameTextBox.TabIndex = 4;
            // 
            // countTextBox
            // 
            this.countTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "Count", true));
            this.countTextBox.Location = new System.Drawing.Point(199, 255);
            this.countTextBox.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.countTextBox.Name = "countTextBox";
            this.countTextBox.Size = new System.Drawing.Size(267, 32);
            this.countTextBox.TabIndex = 8;
            this.countTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.countTextBox_KeyPress);
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "Description", true));
            this.descriptionTextBox.Location = new System.Drawing.Point(199, 373);
            this.descriptionTextBox.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(267, 32);
            this.descriptionTextBox.TabIndex = 12;
            // 
            // butSearchProd
            // 
            this.butSearchProd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.butSearchProd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.butSearchProd.Location = new System.Drawing.Point(27, 418);
            this.butSearchProd.Name = "butSearchProd";
            this.butSearchProd.Size = new System.Drawing.Size(116, 29);
            this.butSearchProd.TabIndex = 13;
            this.butSearchProd.Text = "Найти по коду";
            this.butSearchProd.UseVisualStyleBackColor = false;
            this.butSearchProd.Click += new System.EventHandler(this.butSearchProd_Click);
            // 
            // butAddProd
            // 
            this.butAddProd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.butAddProd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.butAddProd.Location = new System.Drawing.Point(209, 418);
            this.butAddProd.Name = "butAddProd";
            this.butAddProd.Size = new System.Drawing.Size(90, 29);
            this.butAddProd.TabIndex = 14;
            this.butAddProd.Text = "Добавить";
            this.butAddProd.UseVisualStyleBackColor = false;
            this.butAddProd.Click += new System.EventHandler(this.butAddProd_Click);
            // 
            // butDelProd
            // 
            this.butDelProd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.butDelProd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.butDelProd.Location = new System.Drawing.Point(376, 418);
            this.butDelProd.Name = "butDelProd";
            this.butDelProd.Size = new System.Drawing.Size(90, 29);
            this.butDelProd.TabIndex = 15;
            this.butDelProd.Text = "Удалить";
            this.butDelProd.UseVisualStyleBackColor = false;
            this.butDelProd.Click += new System.EventHandler(this.butDelProd_Click);
            // 
            // buttClear
            // 
            this.buttClear.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttClear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttClear.Location = new System.Drawing.Point(27, 463);
            this.buttClear.Name = "buttClear";
            this.buttClear.Size = new System.Drawing.Size(116, 29);
            this.buttClear.TabIndex = 16;
            this.buttClear.Text = "Очистить";
            this.buttClear.UseVisualStyleBackColor = false;
            this.buttClear.Click += new System.EventHandler(this.buttClear_Click);
            // 
            // butSaveProd
            // 
            this.butSaveProd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.butSaveProd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.butSaveProd.Location = new System.Drawing.Point(209, 463);
            this.butSaveProd.Name = "butSaveProd";
            this.butSaveProd.Size = new System.Drawing.Size(257, 29);
            this.butSaveProd.TabIndex = 17;
            this.butSaveProd.Text = "Сохранить запись";
            this.butSaveProd.UseVisualStyleBackColor = false;
            this.butSaveProd.Click += new System.EventHandler(this.butSaveProd_Click);
            // 
            // butTablProd
            // 
            this.butTablProd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.butTablProd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.butTablProd.Location = new System.Drawing.Point(103, 503);
            this.butTablProd.Name = "butTablProd";
            this.butTablProd.Size = new System.Drawing.Size(273, 29);
            this.butTablProd.TabIndex = 18;
            this.butTablProd.Text = "Табличный вид";
            this.butTablProd.UseVisualStyleBackColor = false;
            this.butTablProd.Click += new System.EventHandler(this.butTablProd_Click);
            // 
            // markTextBox
            // 
            this.markTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "Mark", true));
            this.markTextBox.Location = new System.Drawing.Point(199, 316);
            this.markTextBox.Mask = "0.0";
            this.markTextBox.Name = "markTextBox";
            this.markTextBox.Size = new System.Drawing.Size(267, 32);
            this.markTextBox.TabIndex = 20;
            // 
            // priceTextBox
            // 
            this.priceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "Price", true));
            this.priceTextBox.Location = new System.Drawing.Point(199, 190);
            this.priceTextBox.Mask = "00000.00";
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(267, 32);
            this.priceTextBox.TabIndex = 21;
            this.priceTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.priceTextBox_KeyPress);
            // 
            // EditTovarsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 552);
            this.Controls.Add(this.priceTextBox);
            this.Controls.Add(this.markTextBox);
            this.Controls.Add(this.butTablProd);
            this.Controls.Add(this.butSaveProd);
            this.Controls.Add(this.buttClear);
            this.Controls.Add(this.butDelProd);
            this.Controls.Add(this.butAddProd);
            this.Controls.Add(this.butSearchProd);
            this.Controls.Add(descriptionLabel);
            this.Controls.Add(this.descriptionTextBox);
            this.Controls.Add(markLabel);
            this.Controls.Add(countLabel);
            this.Controls.Add(this.countTextBox);
            this.Controls.Add(priceLabel);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(idProductsLabel);
            this.Controls.Add(this.idProductsTextBox);
            this.Controls.Add(this.productsBindingNavigator);
            this.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "EditTovarsForm";
            this.Text = "Товар";
            this.Load += new System.EventHandler(this.EditTovarsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pK_shopDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingNavigator)).EndInit();
            this.productsBindingNavigator.ResumeLayout(false);
            this.productsBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PK_shopDataSet pK_shopDataSet;
        private System.Windows.Forms.BindingSource productsBindingSource;
        private PK_shopDataSetTableAdapters.ProductsTableAdapter productsTableAdapter;
        private PK_shopDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator productsBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton productsBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox idProductsTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox countTextBox;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.Button butSearchProd;
        private System.Windows.Forms.Button butAddProd;
        private System.Windows.Forms.Button butDelProd;
        private System.Windows.Forms.Button buttClear;
        private System.Windows.Forms.Button butSaveProd;
        private System.Windows.Forms.Button butTablProd;
        private System.Windows.Forms.MaskedTextBox markTextBox;
        private System.Windows.Forms.MaskedTextBox priceTextBox;
    }
}